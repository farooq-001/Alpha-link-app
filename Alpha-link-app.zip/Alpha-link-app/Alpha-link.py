from flask import Flask, request, jsonify, render_template
import json
import os
import re
from urllib.parse import urlparse, urlunparse
import requests

app = Flask(__name__)

SYSTEMS_FILE = 'system-list.conf'

def initialize_file():
    if not os.path.exists(SYSTEMS_FILE):
        write_systems([])

def read_systems():
    if os.path.exists(SYSTEMS_FILE) and os.path.getsize(SYSTEMS_FILE) > 0:
        with open(SYSTEMS_FILE, 'r') as file:
            try:
                return json.load(file)
            except json.JSONDecodeError:
                return []
    return []

def write_systems(systems):
    with open(SYSTEMS_FILE, 'w') as file:
        json.dump(systems, file, indent=4)

def normalize_url(url):
    """Normalize URL format to a standard form for consistent comparison."""
    parsed_url = urlparse(url)
    scheme = parsed_url.scheme or 'http'
    netloc = parsed_url.netloc or parsed_url.path.split('/')[0]
    path = parsed_url.path[len(netloc):] if netloc else parsed_url.path
    normalized_url = urlunparse((scheme, netloc, path.rstrip('/'), '', '', ''))
    return normalized_url

def check_port(url):
    """Check if the URL responds to a GET request on its port."""
    try:
        response = requests.get(url, timeout=5)  # 5 seconds timeout
        return response.status_code == 200
    except requests.RequestException:
        return False

@app.route('/')
def index():
    return render_template('alpha-link.html')

@app.route('/systems', methods=['GET'])
def get_systems():
    systems = read_systems()
    return jsonify({'systems': systems})

@app.route('/add_system', methods=['POST'])
def add_system():
    name = request.form.get('name')
    url = request.form.get('url')
    normalized_url = normalize_url(url)
    systems = read_systems()
    if not any(system['url'] == normalized_url for system in systems):
        systems.append({'name': name, 'url': normalized_url})
        write_systems(systems)
    return jsonify({'systems': systems})

@app.route('/remove_system', methods=['POST'])
def remove_system():
    url = request.form.get('url')
    normalized_url = normalize_url(url)
    systems = read_systems()
    systems = [system for system in systems if system['url'] != normalized_url]
    write_systems(systems)
    return jsonify({'systems': systems})

@app.route('/check_status', methods=['POST'])
def check_status():
    url = request.form.get('url')
    normalized_url = normalize_url(url)
    
    # Check if the URL includes a port
    port_match = re.search(r':(\d+)$', normalized_url)
    if port_match:
        port = port_match.group(1)
        # Validate the port by attempting a connection
        if check_port(normalized_url):
            status = 'up'
        else:
            status = 'down'
    else:
        # No port specified, assuming the URL is down if the port is missing
        status = 'down'
    
    return jsonify({'status': status})

if __name__ == '__main__':
    initialize_file()  # Ensure the file is initialized before running the app
    app.run(debug=False)

